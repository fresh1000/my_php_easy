<?php
/**
 * @copyright	amazing-templates.com
 * @author		Tran Nam Chung
 * @mail		chungtn2910@gmail.com
 * @link		http://www.amazing-templates.com
 * @license		License GNU General Public License version 2 or later
 */
defined('_JEXEC') or die;

define('AVATAR_NAME', 'mod_avatar_articles_nivo');
define('AVATAR_DIR', JPATH_ROOT.DIRECTORY_SEPARATOR.'modules'.DIRECTORY_SEPARATOR.AVATAR_NAME.DIRECTORY_SEPARATOR);

