<?php
/**
* @package BJ ImageSlider
* @copyright (C) 2008 byjoomla.com
* @author Doan Ngoc Ha
* @version 2008-12-12 v.1
* 
* --------------------------------------------------------------------------------
* All rights reserved. BJ ImageSlider for Joomla!
*
* --------------------------------------------------------------------------------
**/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class HTML_BJ_ImageSlider {
  
  /**
   * Display a list of all categories
   *
   * @param array $rows
   * @param <var>mosPageNav</var> $pageNav
   */
  function showCategories($rows, $pageNav){
    $option = JRequest::getCmd('option');
    ?>
    <form action="index2.php" method="post" name="adminForm">
		<table class="adminheading">
		<tr>
		  <th class="categories">Category Manager</th>
		  <td nowrap="nowrap"></td>
	  </tr>
	  </table>
	  <table class="adminlist">
		<tr>
			<th width="10" align="left">#</th>
			<th width="20"><input type="checkbox" name="toggle" value="" onClick="checkAll(<?php echo count( $rows );?>);" /></th>
			<th class="title">Category Name</th>
			<th width="10%">Published</th>
			<th colspan="2" width="5%">Reorder</th>
			<th width="2%">Order</th>
			<th width="1%"><a href="javascript: saveorder( <?php echo count( $rows )-1; ?> )"><img src="images/filesave.png" border="0" width="16" height="16" alt="Save Order" /></a></th>
			<th width="5%" nowrap>Category ID</th>
			<th width="20%"></th>
		</tr>
		<?php
		$k = 0;
		for ($i=0, $n=count( $rows ); $i < $n; $i++) {
			$row 	= &$rows[$i];

			$link = 'index2.php?option='. $option . '&act=categories&task=edit&hidemainmenu=1&cid='. $row->id;

			jimport('joomla.html.html.grid');
			$checked = JHTML::_('grid.checkedout', $row, $i );
			$published 	= JHTML::_('grid.published', $row, $i );
			?>
			<tr class="<?php echo "row$k"; ?>">
				<td><?php echo $pageNav->rowNumber( $i ); ?></td>
				<td><?php echo $checked; ?></td>
				<td><a href="<?php echo $link; ?>"><?php echo stripslashes( $row->name ); ?> </a></td>
				<td align="center"><?php echo $published;?></td>
				<td><?php echo $pageNav->orderUpIcon( $i ); ?></td>
				<td><?php echo $pageNav->orderDownIcon( $i, $n ); ?></td>
				<td align="center" colspan="2"><input type="text" name="order[]" size="5" value="<?php echo $row->ordering; ?>" class="text_area" style="text-align: center" /></td>
				<td align="center"><?php echo $row->id; ?></td>
				<td></td>				
				<?php
				$k = 1 - $k;
				?>
			</tr>
			<?php
		}
		?>
		</table>

		<?php echo $pageNav->getListFooter(); ?>

		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="act" value="categories" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="hidemainmenu" value="0" />
		</form>
    <?php
  }
  
  /**
   * Edit or add a category
   * @param dbCategory The category object
   * @param array $lists
   */
	function editCategory( $row, $lists ) {
	  $option = JRequest::getCmd('option');
		?>		
		<script language="javascript" type="text/javascript">
		function submitbutton(pressbutton, section) {
			var form = document.adminForm;
			if (pressbutton == 'cancel') {
				submitform( pressbutton );
				return;
			}

			if ( form.name.value == "" ) {
				alert("Category must have a name");
			} else {
				<?php 
					jimport('joomla.html.editor');
					$editor = &JFactory::getEditor();
					echo $editor->save('description');
				?>				
				submitform(pressbutton);
			}
		}
		</script>
		<form action="index2.php" method="post" name="adminForm">
		<table class="adminheading">
		<tr>
			<th class="categories"><?php echo $row->id ? 'Edit a category' : 'Add a category';?></th>
		</tr>
		</table>

		<table class="adminform">
		<tr>
			<th colspan="3">Category Details</th>
		<tr>
		<tr>
			<td>Category Name:</td>
			<td colspan="2"><input class="text_area" type="text" name="name" value="<?php echo stripslashes( $row->name ); ?>" size="50" maxlength="255" title="A long name to be displayed in headings" /></td>
		</tr>
		<tr>
			<td>Published:</td>
			<td><?php echo $lists['published']; ?></td>
		</tr>
		<tr>
			<td valign="top" colspan="2">Description:</td>
		</tr>
		<tr>
			<td colspan="3">
			<?php
  			// parameters : areaname, content, hidden field, width, height, rows, cols
			$editor = &JFactory::getEditor();
			echo $editor->display('description', $row->description, '100%;', '300', '60', '20');
			?>
			</td>
		</tr>
		</table>

		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="act" value="categories" />
		<input type="hidden" name="id" value="<?php echo $row->id; ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="hidemainmenu" value="0" />
		</form>
		<?php
	}
	
	/**
	 * Show photo's
	 *
	 * @param array $rows
	 * @param <var>mosPageNav</var> $pageNav
	 * @param array $lists
	 */
	function showPhotos($rows, $pageNav, $lists){
	  $option = JRequest::getCmd('option');
    ?>
    <form action="index2.php" method="post" name="adminForm">
		<table class="adminheading">
		<tr>
		  <th class="categories">Manage photo's</th>
		  <td nowrap="nowrap">Category: <?php echo $lists['cid']; ?></td>
	  </tr>
	  </table>
	  <table class="adminlist">
		<tr>
			<th width="10" align="left">#</th>
			<th width="20"><input type="checkbox" name="toggle" value="" onClick="checkAll(<?php echo count( $rows );?>);" /></th>
			<th class="title">Name</th>
			<th colspan="2" width="5%">Reorder</th>
			<th width="2%">Order</th>
			<th width="1%"><a href="javascript: saveorder( <?php echo count( $rows )-1; ?> )"><img src="images/filesave.png" border="0" width="16" height="16" alt="Save Order" /></a></th>
			<th class="title">Category</th>
			<th class="title" width="75">Cat Thumb</th>
			<th class="title" width="75">Published</th>
			<th></th>
		</tr>
		<?php
		$k = 0;
		for ($i=0, $n=count( $rows ); $i < $n; $i++) {
			$row 	= &$rows[$i];

			$link = 'index2.php?option='. $option . '&act=photos&task=edit&hidemainmenu=1&cid='. $row->id;
			
			jimport('joomla.html.html.grid');
			$checked = JHTML::_('grid.checkedout', $row, $i );
			?>
			<tr class="<?php echo "row$k"; ?>">
				<td><?php echo $pageNav->rowNumber( $i ); ?></td>
				<td><?php echo $checked; ?></td>
				<td>
				  <a href="<?php echo $link; ?>">
				  <?php echo  $row->name ; ?>
				  </a>
				</td>
				<td><?php echo $pageNav->orderUpIcon( $i ); ?></td>
				<td><?php echo $pageNav->orderDownIcon( $i, $n ); ?></td>
				<td align="center" colspan="2"><input type="text" name="order[]" size="5" value="<?php echo $row->ordering; ?>" class="text_area" style="text-align: center" /></td>
				<td><?php echo $row->category; ?></td>
				<td><?php echo ($row->default ? '<img src="images/tick.png" border="0" />' : ''); ?></td>
				<td>
				  <a href="javascript:void(0);" onclick="return listItemTask('cb<?php echo $i;?>','<?php echo $row->state ? 'unpublish' : 'publish'; ?>')">
				  <img src="images/<?php echo $row->state ? "tick.png" : "publish_x.png"; ?>" border="0" />
				  </a>
				</td>
				<td></td>
			</tr>
			<?php
			
			$k = 1 - $k;
		}
		?>
		</table>

		<?php echo $pageNav->getListFooter(); ?>

		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="act" value="photos" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="hidemainmenu" value="0" />
		</form>
    <?php
	}
	
	/**
	 * Edit or add a photo
	 * @param dbGallery gallery object
	 * @param array
	 */
	function editPhoto( $row, $lists ) {
	  require_once(PATH_BJ_IMAGESLIDER . DS . 'configuration.php');
	  $option = JRequest::getCmd('option');
	  $mainframe = &JFactory::getApplication();	  
	  ?>
	  <script language="javascript" type="text/javascript">
		function submitbutton(pressbutton, section) {
			var form = document.adminForm;
			if (pressbutton == 'cancel') {
				submitform( pressbutton );
				return;
			}

			<?php jimport('joomla.html.editor');
					$editor = &JFactory::getEditor();
					echo $editor->save('description'); ?>
			submitform(pressbutton);
		}
		</script>
	  
	  <form action="index2.php" method="post" name="adminForm">
		<table class="adminheading">
		<tr>
			<th class="categories"><?php echo $row->id ? 'Edit a photo' : 'Add a photo';?></th>
		</tr>
		</table>

		<table class="adminform">
		<tr>
			<th colspan="3">Photo Details</th>
		<tr>
		<tr>
		  <td width="150">Name:</td>
		  <td><input type="text" name="name" class="text_area" size="30" value="<?php echo $row->name; ?>" /></td>
		  <td rowspan="6"><img src="<?php echo JUri::base(true) . '/..'. $bj_ss_path . '/' . str_replace("-","_",$row->path); ?>" alt="<?php echo stripslashes($row->name); ?>" border="0" width="400px" /></td>
		</tr>
		<tr>
		  <td>Category:</td>
		  <td><?php echo $lists['cid']; ?></td>
		</tr>
		<tr>
		  <td>Gallery thumbnail:</td>
		  <td><?php echo JHTML::_('select.booleanList','default', '', $row->default);?></td>
		</tr>
		<tr>
		  <td>Published:</td>
		  <td><?php echo JHTML::_('select.booleanList','state', '', $row->state); ?></td>
		</tr>
		<tr>
		  <td>CSS Class: <?php echo JHTML::_('tooltip','CSS Class used to apply individual style to each image. Multiple classes are seperated by a white space.\nTo see which style is allowed, follow the introduction in BJ ImageSlider Module.','Help'); ?> </td>
		  <td><input type="text" name="cssclass" class="text_area" size="30" value="<?php echo $row->cssclass; ?>" /></td>
		</tr>
		<tr valign="top">
		  <td>Description:</td>
		  <td><?php 
		    // parameters : areaname, content, hidden field, width, height, rows, cols        
		$editor = &JFactory::getEditor();
			echo $editor->display('description', stripslashes($row->description), '100%;', '300', '60', '20');
        ?>
		  </td>
		</tr>
		<tr>
			<td>Link to:</td>
			<td><input type="text" name="link" class="text_area" size="30" value="<?php echo $row->link; ?>" /></td>
		</tr>
		</table>
		
		<input type="hidden" name="id" value="<?php echo $row->id; ?>" />
		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="act" value="photos" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="hidemainmenu" value="0" />
		</form>
	  <?php
	}
	
	/**
	 * Upload form
	 * 
	 * @param array lists
	 */
	function upload($lists){
	  $mainframe = &JFactory::getApplication();
	  $option = JRequest::getCmd('option');
	  
	  JHTML::_('behavior.tooltip');
	  ?>
	  <script language="javascript" type="text/javascript">
		function submitbutton(pressbutton, section) {
			var form = document.adminForm;
			if (pressbutton == 'cancel') {
				submitform( pressbutton );
				return;
			}

			<?php 	jimport('joomla.html.editor');
					$editor = &JFactory::getEditor();
					echo $editor->save('description'); ?>
					submitform(pressbutton);
		}
		</script>
	  <form action="index2.php" method="post" name="adminForm" enctype="multipart/form-data">
		<table class="adminheading">
		<tr>
			<th class="mediamanager">Upload photo(s)</th>
		</tr>
		</table>
		<br />
		<div align="left" class="small">Upload limit: <?php echo ini_get('upload_max_filesize'); ?></div>
		<table class="adminlist" width="100%">
		<tr>
		  <td width="150">Place in category: </td>
		  <td><?php echo $lists['cid']; ?></td>
		</tr>
		<tr>
		  <td>Default published: </td>
		  <td><?php echo JHTML::_('select.booleanList','state', '', 1); ?></td>
		</tr>
		<tr>
		  <td>Name: <?php echo JHTML::_('tooltip','If you leave this empty, Easy Gallery will use the name of the uploaded image.', 'Help'); ?></td>
		  <td><input type="text" name="name" class="text_area" size="30" value="" /></td>
		</tr>
		<tr>
		  <td>CSS Class: <?php echo JHTML::_('tooltip','CSS Class used to apply individual style to each image. Multiple classes are seperated by a white space.\nTo see which style is allowed, follow the introduction in BJ ImageSlider Module.','Help');?></td>
		  <td><input type="text" name="cssclass" class="text_area" size="30" value="<?php echo $row->cssclass; ?>" /></td>
		</tr>
		<tr>
			<td>Link to:</td>
			<td><input type="text" name="link" class="text_area" size="30" value="<?php echo $row->link; ?>" /></td>
		</tr>
		<tr valign="top">
		  <td>Description: </td>
		  <td><?php 
		    // parameters : areaname, content, hidden field, width, height, rows, cols			
			echo $editor->display('description', $row->description, '100%', '300', '60', '20');
        ?>
		  </td>
		</tr>
		</table>
		<br />
		<div align="left">
		<table class="adminlist" width="100%">
		<tr>
		  <th class="title" colspan="2">Choose File to Upload (as Main Image)</th>
		</tr>
		<tr>
		  <td width="150">File: </td>
		  <td><input type="file" name="photo" class="text_area" size="30" value="" /></td>
		</tr>
		<tr>
		  <th class="title" colspan="2">Choose File to Upload (as Thumnail. If not, a thumbnail is created by default)</th>
		</tr>
		<tr>
		  <td width="150">Thumbnail image: </td>
		  <td><input type="file" name="thumb" class="text_area" size="30" value="" /></td>
		</tr>
		</table>
		</div>
		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="act" value="photos" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="hidemainmenu" value="0" />
		</form>
		<?php
	}
	
	function showConfiguration(){
	  $option = JRequest::getCmd('option');
	  
	  JHTML::_('behavior.tooltip');
	  
	  require(PATH_BJ_IMAGESLIDER . DS . 'configuration.php');
	  ?>
	  <form action="index2.php" method="post" name="adminForm" enctype="multipart/form-data">
		<table class="adminheading">
		<tr>
			<th class="config">Configuration</th>
		</tr>
		</table>
		<table class="adminlist" width="100%">
		<tr>
		  <th class="title" colspan="2">Image Settings</th>
		</tr>
		<tr>
		  <td width="120px">Image width: </td>
		  <td><input type="text" name="bj_ss_config[image_width]" class="text_area" size="10" value="<?php echo $bj_ss_image_width; ?>" /></td>
		</tr>
		<tr>
		  <td>Image height: </td>
		  <td><input type="text" name="bj_ss_config[image_height]" class="text_area" size="10" value="<?php echo $bj_ss_image_height; ?>" /></td>
		</tr>
		<tr>
		  <td>Thumbmail width: </td>
		  <td><input type="text" name="bj_ss_config[thumb_width]" class="text_area" size="10" value="<?php echo $bj_ss_thumb_width; ?>" /></td>
		</tr>
		<tr>
		  <td>Thumbmail height: </td>
		  <td><input type="text" name="bj_ss_config[thumb_height]" class="text_area" size="10" value="<?php echo $bj_ss_thumb_height; ?>" /></td>
		</tr>
		</table>
		<input type="hidden" name="option" value="<?php echo $option; ?>" />
		<input type="hidden" name="task" value="" />
		<input type="hidden" name="act" value="configuration" />
		<input type="hidden" name="boxchecked" value="0" />
		<input type="hidden" name="hidemainmenu" value="0" />
		</form>
	  <?php
	}
	
	function showDefault(){
    $option = JRequest::getCmd('option');
    ?>
    <table class="adminheading">
		<tr>
			<th class="cpanel" rowspan="2" nowrap>BJ ImageSlider Management</th>
	  </tr>
	  </table>
    <table cellpadding="4" cellspacing="0" border="0" width="100%" class="adminform">
	  <tr valign="top">
	    <td width="660">
	    <div id="cpanel">
	      <div style="float:left;">
	      <div class="icon">
  			<a href="index2.php?option=com_bjimageslider&act=configuration">
  				<div class="iconimage">
  					<img src="images/config.png" alt="Configuration" align="middle" name="image" border="0" /></div>
  				Configuration</a>
  		  </div>
  		  </div>
	      <div style="float:left;">
	      <div class="icon">
  			<a href="index2.php?option=com_bjimageslider&act=categories">
  				<div class="iconimage">
  					<img src="images/categories.png" alt="Manage categories" align="middle" name="image" border="0" /></div>
  				Manage Categories</a>
  		  </div>
  		  </div>
	      <div style="float:left;">
	      <div class="icon">
  			<a href="index2.php?option=com_bjimageslider&act=photos">
  				<div class="iconimage">
  					<img src="images/mediamanager.png" alt="Manage photos" align="middle" name="image" border="0" /></div>
  				Manage Photos</a>
  		  </div>
  		  </div>
	    </div>
	    </td>
	    <td>
	    </td>
	  </tr>
	  </table>
    <?php
  }
}

?>