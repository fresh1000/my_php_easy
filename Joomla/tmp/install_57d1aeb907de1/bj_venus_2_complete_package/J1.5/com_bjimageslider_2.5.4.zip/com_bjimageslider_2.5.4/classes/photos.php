﻿<?php
/**
* @package BJ ImageSlider
* @copyright (C) 2008 byjoomla.com
* @author Doan Ngoc Ha
* @version 2009-August-2nd v.1.3
* 
* --------------------------------------------------------------------------------
* All rights reserved. BJ ImageSlider for Joomla!
*
* --------------------------------------------------------------------------------
**/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

set_time_limit(0); //run as long as needed
	  
class photos {
  
  /**
   * Show all photo's
   *
   */
  function show() {
    $database = &JFactory::getDbo();
	$mainframe = &JFactory::getApplication();
	$option = JRequest::getCmd('option');
    
  	$limit = intval( $mainframe->getUserStateFromRequest( "viewlistlimit", 'limit', $mainframe->getCfg('list_limit') ) );
  	$limitstart	= intval( $mainframe->getUserStateFromRequest( "view{$option}limitstart", 'limitstart', 0 ) );
  	$cid	= intval( $mainframe->getUserStateFromRequest( "view{$option}cid", 'cid', 0 ) );
  	
  	$where = array();
  	if($cid > 0){
  	  $where[] = 'g.cid = ' . $cid;
  	}
  	
  	$basequery = "SELECT %s FROM #__bj_ss_items g 
  	  LEFT JOIN #__bj_ss_categories c ON g.cid = c.id ";
  	if(sizeof($where) > 0){
  	  $basequery .= "WHERE " . implode(" AND ", $where);
  	}
  	$basequery .= " ORDER BY cid, g.ordering";
  	
  	$query = str_replace('%s', 'COUNT(1)', $basequery);
  	$database->setQuery($query);
  	$total = $database->loadResult();
  	
  	require_once(JPATH_ADMINISTRATOR . '/includes/pageNavigation.php');
  	$pageNav = new mosPageNav($total, $limitstart, $limit);
  	
  	$query = str_replace("%s", "g.*, c.name AS category", $basequery) . ' LIMIT ' . $limitstart . ', ' . $limit;
  	$database->setQuery($query);
  	$rows = $database->loadObjectList();
  	echo $database->getErrorMsg();
  	
  	// Get all category
  	$categories = categories::getAllCategories();
  	
  	$obj = new stdClass();
  	$obj->id = 0;
  	$obj->name = ' - all - ';
  	
  	array_unshift($categories, $obj);
  	
  	$lists = array();
  	$lists['cid'] = JHTML::_('select.genericlist',$categories, 'cid', 'onchange="document.adminForm.submit();"', 'id', 'name', $cid);
  	
  	HTML_BJ_ImageSlider::showPhotos($rows, $pageNav, $lists);
  }
  
  /**
   * Edit photo
   *
   * @param int $id
   */
  function edit($id){
    $database = &JFactory::getDbo();
    
    $row = new dbPhoto($database);
    $row->load($id);
    
    $categories = categories::getAllCategories();
  	
  	$obj = new stdClass();
  	$obj->id = 0;
  	$obj->name = ' - select - ';
  	
  	array_unshift($categories, $obj);
    
    $lists = array();
  	$lists['cid'] = JHTML::_('select.genericlist',$categories, 'cid', '', 'id', 'name', $row->cid);
    
    HTML_BJ_ImageSlider::editPhoto($row, $lists);
  }
  
  /**
   * Save photo changes
   *
   */
  function save($task){
	$database = &JFactory::getDbo();
	$option = JRequest::getCmd('option');
    
    $row = new dbPhoto($database);
    $row->bind($_POST);
    
    $row->default = intval(JRequest::getVar('default', 0));
    
    if($row->default){
		  $query = 'UPDATE #__bj_ss_items SET `default` = 0 WHERE cid = ' . (int) $row->cid;
		  $database->setQuery($query);
		  $database->query();
		  echo $database->getErrorMsg();
		}
    
    if(!$row->id){
      $row->ordering = 999999999;
    }
    
    if (!$row->check()) {
		echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
		exit();
	}
	if (!$row->store()) {
		echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
		exit();
	}
	$row->reorder('cid = ' . (int) $row->cid);
	
	switch ($task){
	  case 'save':
		$app = &JFactory::getApplication();
$app->redirect('index2.php?option=' . $option . '&act=photos', 'Changes to photo saved');
		break;
	  case 'apply':
		$app = &JFactory::getApplication();
$app->redirect('index2.php?option=' . $option . '&act=photos&task=edit&cid=' . $row->id . '&hidemainmenu=1', 'Changes to photo saved');
		break;
	}
}
  
  /**
   * Remove selected photo's
   *
   * @param array $ids
   */
  function remove($ids, $redirect = true){
    $database = &JFactory::getDbo();
	$mainframe = &JFactory::getApplication();
	$option = JRequest::getCmd('option');
	
    global $bj_ss_path,$bj_ss_thumb_width;
    
    $row = new dbPhoto($database);
    
    for($i=0,$n=count($ids);$i<$n;$i++){
        $id = intval($ids[$i]);
      
        $row->load($id);
        
        $cid = $row->cid;
        $path = $row->path;
        $path = split('/',$path);
        $image_name = $path[count($path) - 1];
        if(file_exists($mainframe->getCfg('absolute_path') . $row->path)){

            if(!unlink($mainframe->getCfg('absolute_path') . $row->path)){
                echo "<script> alert('Failed to remove image: ". $mainframe->getCfg('absolute_path') . $row->path . "'); window.history.go(-1); </script>\n";
			    exit();
            }
        }
        // delete thumbnail
        for($j = 0; $j<count($bj_ss_thumb_width); $j++){
	        if(file_exists($mainframe->getCfg('absolute_path') . $bj_ss_path . '/' . $cid . '/' . 'thumb_' . $j . '_' . $image_name)){
	            if(!unlink($mainframe->getCfg('absolute_path') . $bj_ss_path . '/' . $cid . '/' . 'thumb_' . $j . '_' . $image_name)){
	                echo "<script> alert('Failed to remove image: ". $mainframe->getCfg('absolute_path') . '/' . $bj_ss_path . '/' .  $cid . '/thumb_' . $j . '_' . $image_name . "'); window.history.go(-1); </script>\n";
				    exit();
	            }
	        }
	    }
        
        $row->delete();
        $row->reorder('cid = ' . $cid);
    }
    
    if($redirect){
      $app = &JFactory::getApplication();
$app->redirect('index2.php?option=' . $option . '&act=photos', 'Selected items have been removed');
    } else {
      return $cid;
    }
  }
  
  /**
   * Set a Photo state
   *
   * @param array ids
   * @param int state
   */
  function setState($ids, $state){
    $database = &JFactory::getDbo();
	$option = JRequest::getCmd('option');
    
    $row = new dbPhoto($database);
    
    for($i=0,$n=count($ids);$i<$n;$i++){
    
      $row->load($ids[$i]);
    
      $row->state = $state;
    
      if (!$row->store()) {
			  echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
			  exit();
		  }
    }
    
    $app = &JFactory::getApplication();
$app->redirect('index2.php?option=' . $option . '&act=photos');
  }
  
  /**
   * Move an item up or down
   *
   * @param int $id
   * @param int $direction
   */
  function reorder($id, $direction){
    $database = &JFactory::getDbo();	
	$option = JRequest::getCmd('option');
    
    $row = new dbPhoto($database);
    $row->load($id);
    $row->move($direction, 'cid = ' . (int) $row->cid);
    
    $app = &JFactory::getApplication();
	$app->redirect('index2.php?option=' . $option . '&act=photos');
  }
  
  /**
   * Change ordering of a lot of items
   *
   * @param array $cid
   */
  function saveOrder($cid){
    $database = &JFactory::getDbo();
	$option = JRequest::getCmd('option');
    
    $order = JRequest::getVar('order', array(0) );
    $row = new dbPhoto($database);
    $conditions = array();
    
    for($i=0,$n=count($cid);$i<$n;$i++){
			$row->load($cid[$i]);
			
			if ($row->ordering != $order[$i]) {
				$row->ordering = $order[$i];
				
				if (!$row->store()) {
				  echo "<script> alert('".$database->getErrorMsg()."'); window.history.go(-1); </script>\n";
  				exit();
				}
				
				$condition = 'cid = ' . (int) $row->cid;
				$found = false;
				
				for($j=0,$k=count($conditions);$j<$k;$j++){
				  $cond = $conditions[$j];

				  if ($cond[1] == $condition) {
						$found = true;
						break;
					}
				}
			  if (!$found){
				  $conditions[] = array ($row->id, $condition);
				}
			}
		}

		for($i=0,$n=count($conditions);$i<$n;$i++){
		    $condition = $conditions[$i];
		  
			$row->load($condition[0]);
			$row->reorder($condition[1]);
		}
		
	$app = &JFactory::getApplication();
	$app->redirect('index2.php?option=' . $option . '&act=photos');
  }
  
  /**
   * Display upload form
   *
   */
  function upload(){
    $database = &JFactory::getDbo();
    
    $lists = array();
    $categories = categories::getAllCategories();
    $lists['cid'] = JHTML::_('select.genericlist',$categories, 'cid', 'class="inputbox text_area"', 'id', 'name');
    
    HTML_BJ_ImageSlider::upload($lists);
  }
  
  /**
   * Proccess images after upload
   *
   */
  function handleUpload($redirect = true){
    $database = &JFactory::getDbo();
	$mainframe = &JFactory::getApplication();
	$option = JRequest::getCmd('option');
	
	include (PATH_BJ_IMAGESLIDER . DS .'configuration.php');    
    require_once (PATH_BJ_IMAGESLIDER . DS .'classes' . DS . 'upload.php');
	
    $handle = new Upload($_FILES['photo']);
    $handle_thumb = new Upload($_FILES['thumb']);
    
    $cid = JRequest::getVar('cid', 0);
    $state = JRequest::getVar('state', 0);
    $description = JRequest::getVar('description', '', _MOS_ALLOWHTML);
    $imagename = JRequest::getVar('name', '');
    $cssclass = JRequest::getVar('cssclass', '');
	$link = JRequest::getVar('link', '');
    $time = time();
    $known_images = array('image/pjpeg', 'image/jpeg', 'image/jpg', 'image/png', 'image/x-png', 'image/gif');
    if(!empty($_FILES['photo']['name'])){
      if($_FILES['photo']['error'] > 0){ //error during upload
        switch ($_FILES['photo']['error']){
          case UPLOAD_ERR_INI_SIZE:
            $err_msg = 'The uploaded file exceeds the upload_max_filesize directive in php.ini.';
            break;
          case UPLOAD_ERR_FORM_SIZE:
            $err_msg = 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form.';
            break;
          case UPLOAD_ERR_PARTIAL:
            $err_msg = 'The uploaded file was only partially uploaded.';
            break;
          case UPLOAD_ERR_NO_FILE:
            $err_msg = 'No file was uploaded.';
            break;
          case UPLOAD_ERR_NO_TMP_DIR:
            $err_msg = 'Missing a temporary folder.';
            break;
          case UPLOAD_ERR_CANT_WRITE:
            $err_msg = 'Failed to write file to disk.';
            break;
          case UPLOAD_ERR_EXTENSION:
            $err_msg = 'File upload stopped by extension.';
            break;
          default:
            $err_msg = 'Unknown error';
            break;
        }
        
        echo "<script> alert('Upload error for file ". $_FILES['photo']['name']. ".\\nError message: " . $err_msg . "'); document.location.href='index2.php?option=" . $option . "&act=photos&task=new'; </script>\n";
  		exit();
      }
      
      if(!in_array($_FILES['photo']['type'], $known_images)){
        echo "<script> alert('Photo type: ". $_FILES['photo']['type']. " is an unknown photo type'); document.location.href='index2.php?option=" . $option . "&act=photos&task=new'; </script>\n";
  			exit();
      }
      $image_name = preg_replace('#\W^\.#is', '', $_FILES["photo"]["name"]); //fix up name to get rid of spaces etc
      $image_name = strtolower($image_name); //only lowercase
      $image_name = $time . "_" . $image_name;
	  jimport('joomla.filesystem.file');
	  $image_name = str_replace(" ","_",str_replace("-","_",JFile::makeSafe($image_name)));
      
      if(photos::prepareUploadFolder($cid))
	  {

		  // Do Upload
		  if ($handle->uploaded){
			  $handle->file_safe_name = true;
			  // Copy Original Image
			  // =========================
			  $handle->file_new_name_body = substr($image_name, 0, -3) . '_org';
			  $handle->Process(JPATH_SITE . DS . $bj_ss_absolute_path . DS . $cid);
				
			  // Create Image
			  // =========================
			  
				$handle->image_resize            = true;
				//$handle->image_ratio_y           = true;
				$size = getimagesize($_FILES['photo']['tmp_name']);
				if($bj_ss_image_width < $size[0])
					$handle->image_x                 = $bj_ss_image_width;
				else
					$handle->image_x                 = $size[0];
				//$handle->image_ratio_x           = true;
				if($bj_ss_image_height < $size[1])
					$handle->image_y                 = $bj_ss_image_height;
				else
					$handle->image_y                 = $size[1];
				$handle->file_new_name_body = substr($image_name, 0, -3);
				$handle->Process(JPATH_SITE . DS . $bj_ss_absolute_path . DS . $cid);
			  
			  // Create Thumb
			  //===========================
			  if(!$handle_thumb->uploaded) {
				// create default thumbnail
				
				$handle->image_resize            = true;
				//$handle->image_ratio_y           = true;
				$handle->image_x                 = $bj_ss_thumb_width;
				//$handle->image_ratio_x           = true;
				$handle->image_y                 = $bj_ss_thumb_height;
				$handle->file_new_name_body = substr($image_name, 0, -3)."t";
				$handle->Process(JPATH_SITE . DS . $bj_ss_absolute_path . DS . $cid);
			  } else {
				// create thumbnail by image uploaded
				  
				$handle_thumb->image_resize            = true;
				//$handle->image_ratio_y           = true;
				$handle_thumb->image_x                 = $bj_ss_thumb_width;
				//$handle->image_ratio_x           = true;
				$handle_thumb->image_y                 = $bj_ss_thumb_height;
				$handle_thumb->file_new_name_body = substr($image_name, 0, -3)."t";
				$handle_thumb->Process(JPATH_SITE . DS . $bj_ss_absolute_path . DS . $cid);
			  }
			  $handle->clean();
			  $handle_thumb->clean();
			  
			  if(!$handle->processed){
				echo "<script> alert(\"".$handle->error."\");document.location.href='index2.php?option=" . $option . "&act=photos&task=new'; </script>\n";
				exit();	
			  } 
			  else 
			  {
				  // Insert to DB
				  //===========================
				  $name = (!empty($imagename) ? $imagename : $image_name);
				  photos::insertDBImages($name,$description,$cssclass, $link, $bj_ss_path . '/' . $cid . '/' . $image_name,$cid,$state);
				  
				  if($redirect){
						$app = &JFactory::getApplication();
						$app->redirect('index2.php?option=' . $option . '&act=photos&task=new', 'Photo saved successfully');
				  }
			  }
		  } 
		  else 
		  {
				echo "<script> alert('Upload failed!');document.location.href='index2.php?option=" . $option . "&act=photos&task=new'; </script>\n";
				exit();	
		  }
	  }
    } else {
        echo "<script> alert('No images chosen');document.location.href='index2.php?option=" . $option . "&act=photos&task=new'; </script>\n";
      	exit();
    }
  }
  
  /**
   * Check and create nessecery folder for update files
   *
   * @param string $folder FolderName
   */
  function prepareUploadFolder($folder) {
	include (PATH_BJ_IMAGESLIDER . DS . 'configuration.php');
	// Set FTP credentials, if given
	jimport('joomla.client.helper');
	JClientHelper::setCredentialsFromRequest('ftp');
		
  	jimport('joomla.filesystem.*');
	if(!JFolder::create(JPATH_SITE . $bj_ss_absolute_path)) return false;
	
	jimport('joomla.filesystem.*');
	if(!JFolder::create(JPATH_SITE . $bj_ss_absolute_path . DS . $folder)) return false;
	
	return true;
  }
  
  /**
   * Insert image record to database
   *
   * @param string $name Image Name
   * @param string $desc Image Description
   * @param string $cssclass Image CSS Class
   * @param string $link Image Link URL
   * @param string $path Image Path
   * @param int $cid Category Id
   * @param tinyint $state Image State
   */
  function insertDBImages($name, $desc, $cssclass, $link, $path, $cid, $state) {
  	$database = &JFactory::getDbo();
  	 
    $query = 'SELECT COUNT(1) FROM #__bj_ss_items WHERE cid = ' . (int) $cid;
    $database->setQuery($query);
    $count = $database->loadResult();
    
    $row = new dbPhoto($database);
    $row->name = $name;
    $row->ordering = 99999;
    $row->description = $desc;
    $row->path = $path;
    $row->cid = $cid;
    $row->cssclass = $cssclass;
	$row->link = $link;
    if($count == 0){
      $row->default = 1;
    }
    $row->state = $state;
    
    if (!$row->check()) {
			echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
			exit();
	}
	if (!$row->store()) {
		echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
		exit();
	}
		
	$row->reorder('cid = ' . (int) $row->cid);
  }
}