<?php
/**
* @package BJ ImageSlider
* @copyright (C) 2008 byjoomla.com
* @author Doan Ngoc Ha
* @version 2009-August-2nd v.1/3
* 
* --------------------------------------------------------------------------------
* All rights reserved. BJ ImageSlider for Joomla!
*
* --------------------------------------------------------------------------------
**/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class categories {
  
  /**
   * Show all categories
   *
   */
  function show(){
    $database = &JFactory::getDbo();
	$mainframe = &JFactory::getApplication();
	$option = JRequest::getCmd('option');
	
  	$limit = intval( $mainframe->getUserStateFromRequest( "viewlistlimit", 'limit', $mainframe->getCfg('list_limit') ) );
  	$limitstart	= intval( $mainframe->getUserStateFromRequest( "view{$option}limitstart", 'limitstart', 0 ) );
  	
  	$basequery = "SELECT %s FROM #__bj_ss_categories c ";
  	$basequery .= " ORDER BY ordering";
  	
  	$query = str_replace('%s', 'COUNT(1)', $basequery);
  	$database->setQuery($query);
  	$total = $database->loadResult();
  	
  	require_once(JPATH_ADMINISTRATOR . '/includes/pageNavigation.php');
  	$pageNav = new mosPageNav($total, $limitstart, $limit);
  	
  	$query = str_replace("%s", "*", $basequery);
  	$database->setQuery($query);
  	$rows = $database->loadObjectList();
  	echo $database->getErrorMsg();
  	
  	$lists = array();
  	
  	HTML_BJ_ImageSlider::showCategories($rows, $pageNav, $lists);
  }
  
  /**
   * Edit or add a category
   *
   * @param int $id
   */
  function edit($id){
    $database = &JFactory::getDbo();
	$my = &JFactory::getUser();
	
    $row = new dbCategory($database);
    $row->load($id);
    
    if(!$row->id){
      $row->published = 1;
    }
    
    $lists = array();
	
  	$lists['published'] = JHTML::_('select.booleanlist','published', '', intval($row->published));
  	
    HTML_BJ_ImageSlider::editCategory($row, $lists);
  }
  
  /**
   * Save changes to category
   *
   */
  function save($redirect,$task){
    $database = &JFactory::getDbo();
	$my = &JFactory::getUser();
	$option = JRequest::getCmd('option');
	
    $row = new dbCategory($database);
    $row->bind($_POST);
    
    if(!$row->id){
      $row->ordering = 999999999;
    }
    
    $row->published = intval(JRequest::getVar('published', 0));
    
    if (!$row->check()) {
			echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
			exit();
		}
		if (!$row->store()) {
			echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
			exit();
		}
		
		if($redirect){		
  		switch ($task){
  		  case 'save':
  		    $app = &JFactory::getApplication();
			$app->redirect('index2.php?option=' . $option . '&act=categories', 'Changes to category saved');
  		    break;
  		  case 'apply':
  		    $app = &JFactory::getApplication();
$app->redirect('index2.php?option=' . $option . '&act=categories&task=edit&cid=' . $row->id . '&hidemainmenu=1', 'Changes to category saved');
  		    break;
  		}
		} else {
		  return $row->id;
		}
  }
  
  /**
   * Remove Categorie(s)
   *
   * @param array ids
   */
  function remove($cid, $redirect = true){
    $database = &JFactory::getDbo();
	$option = JRequest::getCmd('option');
    
    $row = new dbCategory($database);
    
    for($i=0,$n=count($cid);$i<$n;$i++){
      $id = $cid[$i];
      
      //check for photos
      $query = "SELECT COUNT(1) FROM #__bj_ss_items WHERE cid = " . (int) $id;
      $database->setQuery($query);
      $total = $database->loadResult();
      
      if($total > 0){
        echo "<script> alert('" . addslashes(EG_CAT_DELETE_STILL_PHOTOS) . "'); window.history.go(-1); </script>\n";
  			exit();
      }
      
      $row->delete($id);
    }
    
    if($redirect){
      $app = &JFactory::getApplication();
$app->redirect('index2.php?option=' . $option . '&act=categories', 'Selected categories removed');
    }
  }
  
  /**
   * Set a Category state
   *
   * @param int id
   * @param int published
   */
  function setState($id, $published){
    $database = &JFactory::getDbo();
	$option = JRequest::getCmd('option');
    
    $row = new dbCategory($database);
    $row->load($id);
    
    $row->published = $published;
    
    if (!$row->store()) {
			echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
			exit();
		}
    
    $app = &JFactory::getApplication();
	$app->redirect('index2.php?option=' . $option . '&act=categories');
}
  
  /**
   * Move an item up or down
   *
   * @param int $id
   * @param int $direction
   */
function reorder($id, $direction){
    $database = &JFactory::getDbo();
	$option = JRequest::getCmd('option');
    
    $row = new dbCategory($database);
    $row->load($id);    
    $row->move($direction, '');
	
    $app = &JFactory::getApplication();
	$app->redirect('index2.php?option=' . $option . '&act=categories');
}
  
  /**
   * Change ordering of a lot of items
   *
   * @param array $cid
   */
  function saveOrder($cid){
    $database = &JFactory::getDbo();	
	$option = JRequest::getCmd('option');
    
    $order = JRequest::getVar('order', array(0) );
    $row = new dbCategory($database);
    $conditions = array();
    
    for($i=0,$n=count($cid);$i<$n;$i++){
			$row->load($cid[$i]);
			
			if ($row->ordering != $order[$i]) {
				$row->ordering = $order[$i];
				
				if (!$row->store()) {
				  echo "<script> alert('".$database->getErrorMsg()."'); window.history.go(-1); </script>\n";
  				exit();
				}

				$found = false;
				
				for($j=0,$k=count($conditions);$j<$k;$j++){
				  $cond = $conditions[$j];

				  if ($cond[1] == $condition) {
						$found = true;
						break;
					}
				}
			  if (!$found){
				  $conditions[] = array ($row->id, $condition);
				}
			}
		}

		for($i=0,$n=count($conditions);$i<$n;$i++){
		  $condition = $conditions[$i];
		  
			$row->load($condition[0]);
			$row->reorder($condition[1]);
		}
		
		$app = &JFactory::getApplication();
		$app->redirect('index2.php?option=' . $option . '&act=categories');
  }
  
  /**
   * Get all categories
   *
   * @return array
   */
  function getAllCategories($published_only = false){
    $database = &JFactory::getDbo();
	$mainframe = &JFactory::getApplication();	
    
    $query = "SELECT id,name FROM #__bj_ss_categories ";

    if($published_only){
      $query .= "AND published = 1";
    }
    $query .= "ORDER BY ordering";
    $database->setQuery($query);
    $rows = $database->loadObjectList();
    
    return $rows;
  }
}