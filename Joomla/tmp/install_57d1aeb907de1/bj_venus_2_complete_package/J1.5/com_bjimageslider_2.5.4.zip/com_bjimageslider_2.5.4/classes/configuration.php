<?php
/**
* @package BJ ImageSlider
* @copyright (C) 2008-2010 byjoomla.com
* @author Doan Ngoc Ha
* @version 2010-January-04th v.1.5.1
* 
* --------------------------------------------------------------------------------
* All rights reserved. BJ ImageSlider for Joomla!
*
* --------------------------------------------------------------------------------
**/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class configuration {
	function saveConfiguration($task){
		$database = &JFactory::getDbo();
		$option = JRequest::getCmd('option');
	    
		$config = JRequest::getVar('bj_ss_config');
		ksort($config);
	    
	    $content = '<?php
/**
* @package BJ ImageSlider
* @copyright (C) 2008-2010 byjoomla.com
* @author byjoola.com
* @version 2010-January-04th v.1.5.1
* 
* --------------------------------------------------------------------------------
* All rights reserved. BJ ImageSlider for Joomla!
*
* --------------------------------------------------------------------------------
**/

defined( \'_JEXEC\' ) or die( \'Restricted access\' );
if(!defined(\'DS\'))
	define(\'DS\', DIRECTORY_SEPARATOR);
$bj_ss_path = \'/images/stories/_bj_imageslider\';
$bj_ss_absolute_path = DS . \'images\' . DS . \'stories\' . DS . \'_bj_imageslider\';
';
	  $keys = array_keys($config);
	  for($i=0,$n=count($keys);$i<$n;$i++){
	    if (!ini_get('magic_quotes_gpc')){
	      $config[$keys[$i]] = addslashes($config[$keys[$i]]);
	    }
	    $content .= '$bj_ss_' . $keys[$i] . ' = \'' . $config[$keys[$i]] . "';\n";
	  }
	  $content .= "\n?>";
	  
	  if(!is_writable(PATH_BJ_IMAGESLIDER . DS . 'configuration.php')){
	    $app = &JFactory::getApplication();
		$app->redirect('index2.php?option=' . $option . '&act=configuration', 'Configuration file is not writable');
	    return;
	  }
	  
	  $fp = fopen(PATH_BJ_IMAGESLIDER . DS . 'configuration.php', 'w');
	  fwrite($fp, $content);
	  fclose($fp);
	  
	  switch ($task){
		  case 'save':
		    $app = &JFactory::getApplication();
			$app->redirect('index2.php?option=' . $option . '', 'Configuration saved');
		    break;
		  case 'apply':
		    $app = &JFactory::getApplication();
			$app->redirect('index2.php?option=' . $option . '&act=configuration', 'Configuration saved');
		    break;
		}
	}
}
?>