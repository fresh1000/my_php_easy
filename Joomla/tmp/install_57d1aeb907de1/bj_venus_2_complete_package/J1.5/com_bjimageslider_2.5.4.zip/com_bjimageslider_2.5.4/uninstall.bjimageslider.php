<?php
/**
* @package BJ ImageSlider
* @copyright (C) 2008 byjoomla.com
* @author Doan Ngoc Ha
* @version 2009-August-2nd v.1.3
* 
* --------------------------------------------------------------------------------
* All rights reserved. BJ ImageSlider for Joomla!
*
* --------------------------------------------------------------------------------
**/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

function com_uninstall(){  
}

?>