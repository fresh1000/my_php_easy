<?php
/**
* @package BJ ImageSlider
* @copyright (C) 2008-2010 byjoomla.com
* @author byjoola.com
* @version 2010-January-04th v.1.5.1
* 
* --------------------------------------------------------------------------------
* All rights reserved. BJ ImageSlider for Joomla!
*
* --------------------------------------------------------------------------------
**/

defined( '_JEXEC' ) or die( 'Restricted access' );
if(!defined('DS'))
	define('DS', DIRECTORY_SEPARATOR);
$bj_ss_path = '/images/stories/bj_imageslider';
$bj_ss_absolute_path = DS . 'images' . DS . 'stories' . DS . 'bj_imageslider';
$bj_ss_image_height = '300';
$bj_ss_image_width = '650';
$bj_ss_thumb_height = '35';
$bj_ss_thumb_width = '52';

?>