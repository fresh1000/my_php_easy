<?php
/**
* @package BJ ImageSlider
* @copyright (C) 2009 byjoomla.com
* @author Doan Ngoc Ha
* @version 2009-November-14th v.1.5
* 
* --------------------------------------------------------------------------------
* All rights reserved. BJ ImageSlider for Joomla!
*
* --------------------------------------------------------------------------------
**/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

define("PATH_BJ_IMAGESLIDER", dirname(__FILE__));
if(!defined("DS"))
	define("DS", DIRECTORY_SEPARATOR);
	
require_once(PATH_BJ_IMAGESLIDER . DS . 'classes' . DS . 'categories.php');
require_once(PATH_BJ_IMAGESLIDER . DS . 'classes' . DS . 'photos.php');
require_once(PATH_BJ_IMAGESLIDER . DS . 'classes' . DS . 'upload.php');
require_once(PATH_BJ_IMAGESLIDER . DS . 'classes' . DS . 'configuration.php');

require(PATH_BJ_IMAGESLIDER . DS . 'configuration.php');

class dbPhoto extends JTable {
  /** @var int ID **/
  var $id = null;
  /** @var int category id **/
  var $cid = null;
  /** @var string name **/
  var $name = null;
  /** @var text description **/
  var $description = null;
  /** @var string cssclass **/
  var $cssclass = null;
  /** @var string path **/
  var $path = null;
  /** @var string link **/
  var $link = null;
  /** @var boolean default **/
  var $default = null;
  /** @var int ordering **/
  var $ordering = null;
  /** @var tinyint state **/
  var $state = null;
  
  function dbPhoto(&$db){
    parent::__construct('#__bj_ss_items', 'id', $db);
  }
}

class dbCategory extends JTable {
  /** @var int ID **/
  var $id = null;
  /** @var string name **/
  var $name = null;
  /** @var text description **/
  var $description = null;
  /** @var int ordering **/
  var $ordering = null;
  /** @var tinyint state **/
  var $published = null;
  
  function dbCategory(&$db){
    parent::__construct('#__bj_ss_categories', 'id', $db);
  }
}
	

?>