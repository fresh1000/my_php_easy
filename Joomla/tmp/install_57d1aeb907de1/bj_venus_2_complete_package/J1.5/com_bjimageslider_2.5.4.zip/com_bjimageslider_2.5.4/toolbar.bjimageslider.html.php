<?php
/**
* @package BJ ImageSlider
* @copyright (C) 2008 byjoomla.com
* @author Doan Ngoc Ha
* @version 2009-August-2nd v.1.3
* 
* --------------------------------------------------------------------------------
* All rights reserved. BJ ImageSlider for Joomla!
*
* --------------------------------------------------------------------------------
**/
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class TOOLBAR_BJ_ImageSlider {
	function _EDIT() {
		global $id;		
		JToolbarHelper::spacer();
		JToolbarHelper::save();
		JToolbarHelper::spacer();
		JToolbarHelper::apply();
		JToolbarHelper::spacer();
		JToolbarHelper::cancel();
	}
	
	function _SAVE() {
		global $id;
		
		JToolbarHelper::spacer();
		JToolbarHelper::save();
		JToolbarHelper::spacer();
		JToolbarHelper::cancel();
		
	}

	function _DEFAULT() {		
		JToolbarHelper::deleteListX();
		JToolbarHelper::spacer();
		JToolbarHelper::editListX();
		JToolbarHelper::spacer();
		JToolbarHelper::addNewX();		
	}
	
	function _DEFAULT_PHOTOS() {		
		JToolbarHelper::publishList();
		JToolbarHelper::unpublishList();
		JToolbarHelper::divider();
		JToolbarHelper::deleteListX();
		JToolbarHelper::spacer();
		JToolbarHelper::editListX();
		JToolbarHelper::spacer();
		JToolbarHelper::custom('new', 'upload.png', 'upload_f2.png', 'Upload', false);		
	}
	
	function _EDIT_PHOTOS() {
		global $id;		
		JToolbarHelper::custom('upload', 'upload.png', 'upload_f2.png', 'Upload', false);
		JToolbarHelper::cancel('cancel', 'Close');	
	}
}
?>