<?php
/**
* @package BJ ImageSlider
* @copyright (C) 2008 byjoomla.com
* @author Doan Ngoc Ha
* @version 2009-August-2nd v.1.3
* 
* --------------------------------------------------------------------------------
* All rights reserved. BJ ImageSlider for Joomla!
*
* --------------------------------------------------------------------------------
**/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

require_once( JApplicationHelper::getPath( 'toolbar_html' ) );

$act = JRequest::getVar('act');

if(empty($act) || ($act == 'updates')){
  return;
}
if($act == 'configuration'){
  TOOLBAR_BJ_ImageSlider::_EDIT();
  return;
}
if($act == 'photos'){
  switch ($task) {
  	case 'new':
  	  TOOLBAR_BJ_ImageSlider::_EDIT_PHOTOS();
  	  break;
  	case 'edit':
  	  TOOLBAR_BJ_ImageSlider::_EDIT();
  	  break;  
  	default:
  	  TOOLBAR_BJ_ImageSlider::_DEFAULT_PHOTOS();
  	  break;
  }
  return;
}
switch ($task) {
	case 'add':
	case 'edit':
	  TOOLBAR_BJ_ImageSlider::_EDIT();
	  break;
	default:
      TOOLBAR_BJ_ImageSlider::_DEFAULT();
	  break;
}
?>