<?php
/**
* @package BJ ImageSlider
* @copyright (C) 2008 byjoomla.com
* @author Doan Ngoc Ha
* @version 2009-August-2nd v.1.3
* 
* --------------------------------------------------------------------------------
* All rights reserved. BJ ImageSlider for Joomla!
*
* --------------------------------------------------------------------------------
**/

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
$mainframe = &JFactory::getApplication();

require_once($mainframe->getPath('class'));
require_once($mainframe->getPath('admin_html'));

$task = JRequest::getVar('task');
$act = JRequest::getVar('act');
$cid = JRequest::getVar('cid', array(0));

if(!is_array($cid)){
  $cid = array($cid);
}
switch ($act){
  case 'categories':
    swCategories($task, $cid);
    break;
  case 'photos':
    swPhotos($task, $cid);
    break;
  case 'configuration':
    swConfiguration($task, $cid);
    break;
  default:
    HTML_BJ_ImageSlider::showDefault();
    break;
}


/**
 * Switch for photos
 *
 * @param string $task
 * @param array $cid
 */
function swPhotos($task, $cid){
  $option = JRequest::getCmd('option');  
  switch ($task){
    case 'new':
      photos::upload();
      break;
    case 'edit':
      photos::edit($cid[0]);
      break;
    case 'apply':
    case 'save':
      photos::save($task);
      break;
    case 'remove':
      photos::remove($cid);
      break;
    case 'cancel':
      $app = &JFactory::getApplication();
		$app->redirect('index2.php?option=' . $option . '&act=photos');
      break;
    case 'orderup':
      photos::reorder($cid[0], -1);
      break;
    case 'orderdown':
      photos::reorder($cid[0], 1);
      break;
    case 'saveorder':
      photos::saveOrder($cid);
      break;
    case 'publish':
      photos::setState($cid, 1);
      break;
    case 'unpublish':
      photos::setState($cid, 0);
      break;
    case 'upload':
      photos::handleUpload();
      break;
    default:
      photos::show();
      break;
  }
}

/**
 * Switch for categories
 *
 * @param string $task
 * @param array $cid
 */
function swCategories($task, $cid){
  $option = JRequest::getCmd('option');
  switch ($task){
    case 'add':
      categories::edit(0);
      break;
    case 'edit':
      categories::edit($cid[0]);
      break;
    case 'apply':
    case 'save':
      categories::save(true,$task);
      break;
    case 'remove':
      categories::remove($cid);
      break;
    case 'cancel':
      $app = &JFactory::getApplication();
		$app->redirect('index2.php?option=' . $option . '&act=categories');
      break;
    case 'orderup':
      categories::reorder($cid[0], -1);
      break;
    case 'orderdown':
      categories::reorder($cid[0], 1);
      break;
    case 'saveorder':
      categories::saveOrder($cid);
      break;
    case 'publish':
      categories::setState($cid[0], 1);
      break;
    case 'unpublish':
      categories::setState($cid[0], 0);
      break;
    default:
      categories::show();
      break;
  }
}

function swConfiguration($task){
  $option = JRequest::getCmd('option');
  
  switch ($task){
    case 'save':
    case 'apply':
      configuration::saveConfiguration($task);
      break;
    case 'cancel':
      $app = &JFactory::getApplication();
$app->redirect('index2.php?option=' . $option);
      break;
    default:
      HTML_BJ_ImageSlider::showConfiguration();
      break;
  }
}
?>