<?php defined('_JEXEC') or die('Restricted access'); 
$app =& JFactory::getApplication();
JLoader::register('JAddons', JPATH_THEMES.DS.$app->getTemplate().DS.'read_tpl_params.php');

$componentheading  = JAddons::getTplParams()->get('componentheading');?>

<?php if ( $this->params->get( 'show_page_title', 1 ) ) : ?>
<div class="componentheading<?php echo $this->escape($this->params->get('pageclass_sfx')); ?>">
	<span class="left"></span><?php echo "<" . $componentheading . ">" . $this->escape($this->params->get('page_title')) . "</" . $componentheading . ">"; ?><span class="right"></span>
</div>
<?php endif; ?>

<?php echo $this->loadTemplate('form'); ?>
<?php if(!$this->error && count($this->results) > 0) :
	echo $this->loadTemplate('results');
else :
	echo $this->loadTemplate('error');
endif; ?>
