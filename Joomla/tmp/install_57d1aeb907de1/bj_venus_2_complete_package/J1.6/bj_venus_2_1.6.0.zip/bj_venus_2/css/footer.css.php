<div class="tips">
	<a href="http://byjoomla.com" title="Joomla template by ByJoomla.com"><strong>Joomla template by ByJoomla.com</strong></a>
</div>