<?php
if (extension_loaded('zscripts') && !ini_get('zscripts.output_compression')) @ob_start('ob_gzhandler');

header('Content-type: text/css; charset: UTF-8');
header('Cache-Control: must-revalidate');
header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 3600) . ' GMT');

define('DS', DIRECTORY_SEPARATOR);
define('PATH_ROOT', dirname(__FILE__) . DS);

$cssPath = PATH_ROOT;

//css path | css file name | css browser1
//css browser = "all" for all browser, "browser1,browser2,..." for defined various browser only
//IE = msie 6
//IE with various version = msie parent version or full version, e.g. "msie 6" or "msie 5.5" or "msie 5.0.1"
//IE 4 = msie 4
//IE 5 = msie 5
//IE 6 = msie 6
//IE 7 = msie 7
//IE 7 = msie 7

//Opera = opera
//Opera with various version = opera/version, e.g. "opera/9.10"
//Firefox = firefox
//Firefox with various version = firefox/version, e.g. "firefox/2.0.0.14"

$cssGZIP[] = $cssPath."|base.css|all";
$cssGZIP[] = $cssPath."|layout.css|all";
$cssGZIP[] = $cssPath."|custom.css|all";
$cssGZIP[] = $cssPath."|typo.css|all";
$cssGZIP[] = $cssPath."|bj_dropdownmenu.css|all";

if(!empty($_GET['color'])) {
	$cssGZIP[] = $cssPath."|".$_GET['color'].".css|all";
}

foreach($cssGZIP as $GZIP) {
	$css = explode("|", $GZIP);
	if($css[2]=="all") {
		if(file_exists($css[0].$css[1])) {
		include($css[0].$css[1]);
		}
	} else {
		$browsers = explode(",", $css[2]);
		$loadThisCSS = false;
		foreach($browsers as $browser) {
			if(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), $browser) !== false) {
				$loadThisCSS = true;
			}
		}
		if($loadThisCSS == true) {
			if(file_exists($css[0].$css[1])) {
				include($css[0].$css[1]);
			}
		}
	}
}

?>