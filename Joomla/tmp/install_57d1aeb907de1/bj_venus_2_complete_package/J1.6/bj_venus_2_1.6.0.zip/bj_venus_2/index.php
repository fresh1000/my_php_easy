<?php
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/* === Get Template parameters ================================== */
$template_color = $this->params->get("templateColor","blue");

$moduleheading = $this->params->get("moduleheading","h3");

$pathway_text = $this->params->get("pathway_text","");
$backtotop = $this->params->get("backtotop","");

$btn_fb = $this->params->get("btn_fb","");
$btn_tweet = $this->params->get("btn_tweet","");
$btn_rss = $this->params->get("btn_rss","");

$advert2_width = $this->params->get("advert2_width","200");
$advert2_height = $this->params->get("advert2_height","280");
/* === End parameters =========================================== */
$template_name = 'bj_venus_2';
global $template_font;

define( '_TEMPLATE_PATH', JPATH_BASE . DS . 'templates' . DS .$template_name);
define('_TEMPLATE_URL',JURI::base().'templates/'.$template_name);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >
<head>
<jdoc:include type="head" />
<?php
	$user_count = 0;
	$header = 0;
	$left = 0;
	$right = 0;
	$banner = 0;
	$headline = 0;
	$user1 = 0;$user2 = 0;$user3 = 0;$user4 = 0;$user5 = 0;
	$top = 0;
	$bottom = 0;
	$advert1 = 0;
	$advert2 = 0;
	$toolbar = 1;
	$cpanel = 0;
	$top_mod_1_loaded = 0;$top_mod_2_loaded = 0;
	if($this->countModules('user1')) { $user1 = 1;$user_count++;}
	if($this->countModules('user2')) { $user2 = 1;$user_count++;}
	if($this->countModules('user3')) { $user3 = 1;$user_count++;}
	if($this->countModules('user4')) { $user4 = 1;$user_count++;}
	if($this->countModules('user5')) { $user5 = 1;$user_count++;}
	if($this->countModules('user6')) { $user6 = 1;}
	if($this->countModules('left')) { $left = 1;}
	if($this->countModules('right')) { $right = 1;}
	if($this->countModules('cpanel')) { $cpanel = 1;}
	if($this->countModules('advert1')) { $advert1 = 1;}
	if($this->countModules('advert2')) { $advert2 = 1;}	
	if($this->countModules('toolbar')) { $toolbar = 1;}	
	if($this->countModules('header')){$header=1;}	
	if($this->countModules('bottom')){$bottom=1;}
	if($this->countModules('top')){$top=1;}
	if($this->countModules('banner')){$banner=1;}	
	if($this->countModules('headline')){$headline=1;}	
	if($this->countModules($top_mod_1_position)){$top_mod_1_loaded=1;}
	if($this->countModules($top_mod_2_position)){$top_mod_2_loaded=1;}
?>
<?php 
$theme_name = 'theme1';
$file = JPATH_BASE.DS.'components'.DS.'com_bjthemes'.DS.'bj_themeloader.php';
$load_theme_result = false;
/*
if(file_exists($file)){
	$app =& JFactory::getApplication();
	JLoader::register('BJ_ThemeLoader', $file);
	if(BJ_ThemeLoader::loadTheme($app->getTemplate(),$theme_name)){
		$load_theme_result = true;
	}
}
*/
if(!$load_theme_result){
?>
<script type="text/javascript" src="<?php echo _TEMPLATE_URL?>/func/jquery-1.4.2.js"></script>
<script type="text/javascript">
		jQuery.noConflict();
		var _TEMPLATE_URL = '<?php echo _TEMPLATE_URL ?>';
		<?php if($top_mod_click == "0"){?>
		var _TOPMOD_HOVER = true;
		<?php } else {?>
		var _TOPMOD_HOVER = false;
		<?php }?>
</script>
<link rel="stylesheet" href="<?php echo _TEMPLATE_URL ?>/css/template_css.css" type="text/css" />
<link rel="stylesheet" href="<?php echo _TEMPLATE_URL ?>/css/bj_dropdownmenu.css" type="text/css" />
<link rel="stylesheet" href="<?php echo _TEMPLATE_URL ?>/css/<?php echo $template_color; ?>.css" type="text/css" />

<style type="text/css">
#BJ_Venus_ContentSlider{width:<?php echo $advert2_width;?>px;height:<?php echo $advert2_height;?>px}
#BJ_Venus_ContentSlider #BJ_Social_Buttons{width:<?php echo $advert2_width - 15;?>px;}
<?php if($top_mod_click == "0"){?>
#BJ_Top_Mod_1.mouseover .content,#BJ_Top_Mod_2.mouseover .content{left:0}
<?php }?>
<?php if($left == 0){?>
#BJ_Right_Col{margin-left:0;width:960px}
#BJ_Main_Top_Round,#BJ_Main_Bottom_Round{width:952px}
#BJ_Main_Bottom_Round{margin-left:4px}
	<?php if(!$right){?>
#BJ_Main{width:920px}
	<?php } else {?>
#BJ_Main{width:700px}
<?php }}?>
<?php if(!$right){?>
#BJ_Main{width:700px}
	<?php if(!$left){?>
#BJ_Main{width:920px}
	<?php }?>
<?php }?>
</style>
<!--[if IE]>
<style type="text/css">
div.componentheading .left{margin-top:-7px}

/* FIX COLOR IN IE */
.venus-textbox-2 div.blue{background:#002545;}
.venus-textbox-2 div.green{background:#173100}
.venus-textbox-2 div.purple{background:#321039}
.venus-textbox-2 div.orange{background:#D16500}
.venus-textbox-2 div.brown{background:#2F261B}
.venus-textbox-2 div.red{background:#610004}
</style>
<![endif]-->
<!--[if IE 7]>
<?php if($left == 0){?>
<style type="text/css">
#BJ_MainBody{margin:0}
<?php }?>
#BJ_Search .typo-search{margin:-26px -25px 0 0}
div.bjmod-style-2 h3 .bjmod-head-r,div.bjmod-style-3 h3 .bjmod-head-r,div.bjmod-style-2 h4 .bjmod-head-r,div.bjmod-style-3 h4 .bjmod-head-r,div.bjmod-style-2 h5 .bjmod-head-r,div.bjmod-style-3 h5 .bjmod-head-r{margin:-19px -7px 0 0;}
div.componentheading .left{margin-top:-7px}
div.componentheading .right{margin-top:-49px}
.button-1-,.button-1-blue,.button-1-green,.button-1-orange,.button-1-purple,.button-1-brown,.button-1-red{padding:0;}
.button-2-,.button-2-blue,.button-2-green,.button-2-orange,.button-2-purple,.button-2-brown,.button-2-red{padding:9px 0}
a.button-2 .front{top:10px}
</style>
<![endif]-->
<?php }?>
</head>
<body>
<center>
<div id="BJ_Wrapper">
<?php if($top_mod_1_loaded || $top_mod_2_loaded){?>
<div id="BJ_TopBar" class="wrapper">
	<center>
		<div class="inner">
			<?php if($top_mod_1_loaded){?>
			<div id="BJ_Top_Mod_1" class="collapsible">
				<div class="title"><span class="<?php echo $top_mod_1_icon;?>"></span><?php echo $top_mod_1_text;?></div>
				<div class="content float-hide">
					<jdoc:include type="modules" name="<?php echo $top_mod_1_position;?>" heading="<?php echo  $moduleheading;?>" style="venus" />
				</div>
			</div>
			<?php }?>
			<?php if($top_mod_2_loaded){?>
			<div id="BJ_Top_Mod_2" class="collapsible">
				<div class="title"><span class="<?php echo $top_mod_2_icon;?>"></span><?php echo  $top_mod_2_text;?></div>
				<div class="content float-hide">
					<jdoc:include type="modules" name="<?php echo  $top_mod_2_position;?>" heading="<?php echo $moduleheading;?>" style="venus" />
				</div>
			</div>
			<?php }?>
		</div>
	</center>
</div>
<div class="clearer"><!-- --></div>
<?php }?>
<div id="BJ_MainPage">
	<div class="inner">
		<div id="BJ_Logo_Search">
			<div id="BJ_Logo">
			<?php if(!$header) {?>
				<div style="height:50px;padding:20px 0 0 0" title="<?php echo $GLOBALS['mosConfig_sitename']; ?>">
					<a href="<?php echo $GLOBALS['mosConfig_live_site']; ?>" title="<?php echo $GLOBALS['mosConfig_sitename']; ?>">
						<?php $src = _TEMPLATE_URL . '/images/v2-bj-venus-logo.png';
						?>
						<img src="<?php echo  $src; ?>" alt=""/>
					</a>
				</div>
			<?php } else {?>
			<jdoc:include type="modules" name="header" style="raw" />
			<?php }?>
			</div>
			<?php if($user5){?>
			<div id="BJ_Search">
				<jdoc:include type="modules" name="user5" style="raw" /><span class="icon"><!-- --></span>
			</div>
			<?php }?>
		</div>
	</div>
	<?php if($toolbar){?>
	<div class="inner2">
		<div class="clearer"><!-- --></div>
		<div id="BJ_MainMenu" class="dropdown">
			<div class="bg">
				<div class="bg">
					<jdoc:include type="modules" name="toolbar" style="raw"/>
				</div>
				<div class="clearer"><!-- --></div>
			</div>
			<div class="clearer"><!-- --></div>
		</div>
	</div>
	<?php }?>
	<div class="inner">
		<?php if($advert1){?>
		<div class="clearer"><!-- --></div>
		<div id="BJ_Venus_SlideShow">
			<jdoc:include type="modules" name="advert1" style="raw" />
		</div>
		<?php }?>
		<?php if($advert2){?>
		<div id="BJ_Venus_ContentSlider">
			<span id="BJ_Venus_ContentSlider_TopLeft"><!-- --></span>
			<span id="BJ_Venus_ContentSlider_BottomLeft"><!-- --></span>
			<jdoc:include type="modules" name="advert2" style="xhtml"/>
			<div class="clearer"><!-- --></div>
			<?php if($btn_fb || $btn_tweet || $btn_rss){?>
			<div id="BJ_Social_Buttons" class="moduletable">
				<?php if($btn_fb){?>
					<a href="<?php echo $btn_fb;?>" alt=""><img src="<?php echo _TEMPLATE_URL . '/images/v2-fb-btn.png'; ?>" alt=""/></a>
				<?php }?>
				<?php if($btn_tweet){?>
					<a href="<?php echo $btn_tweet;?>" alt=""><img src="<?php echo _TEMPLATE_URL . '/images/v2-tweet-btn.png'; ?>" alt=""/></a>
				<?php }?>
				<?php if($btn_rss){?>
					<a href="<?php echo $btn_rss;?>" alt=""><img src="<?php echo _TEMPLATE_URL . '/images/v2-rss-btn.png'; ?>" alt=""/></a>
				<?php }?>
			</div>
			<?php }?>
		</div>
		<?php }?>
		<div class="clearer"><!-- --></div>
		<?php if($headline){?>
			<div id="BJ_Headline">
				<jdoc:include type="modules" name="headline" style="raw" />
			</div>
			<div class="clearer"><!-- --></div>
		<?php }?>
		<div id="BJ_MainBody">
			<div id="BJ_Left_Col"><jdoc:include type="modules" name="left" heading="<?php echo  $moduleheading;?>" style="venus" /></div>
			<div id="BJ_Right_Col">
				<div id="BJ_Main">
					<?php if($top){?>
					<div id="BJ_Top">
						<jdoc:include type="modules" name="top" style="raw" />
					</div>
					<div class="clearer"><!-- --></div>
					<?php }?>
					<div id="BJ_Component">
						<jdoc:include type="message" />
						<jdoc:include type="component" />
					</div>
					<div class="clearer"><!-- --></div>
					<div id="BJ_Bottom">
						<jdoc:include type="modules" name="bottom" heading="<?php echo $moduleheading;?>" style="venus" />
					</div>
					<div class="clearer"><!-- --></div>
					<?php if($banner){?>
					<div id="BJ_Banner">
						<jdoc:include type="modules" name="banner" style="raw" />
					</div>
					<div class="clearer"><!-- --></div>
					<?php }?>
				</div>
				<?php if($right){?>
				<div id="BJ_Right">
					<jdoc:include type="modules" name="right" heading="<?php echo $moduleheading;?>" style="venus" />
				</div>
				<?php }?>
				<div class="clearer"><!-- --></div>
			</div>
		</div>
	</div>
</div>
<div class="clearer"><!-- --></div>
<div id="BJ_BottomPage">
	<div id="BJ_Pathway">
		<div class="inner">
			<span class="path"><?php echo $pathway_text;?> <jdoc:include type="modules" name="breadcrumbs"/></span>
			<?php if($backtotop){?>
			<div id="BJ_Gotop"><a href="javascript:void(0)" onclick="window.scrollTo(0,0)"><?php echo $backtotop;?></a></div><?php }?>
		</div>
	</div>
	<div class="clearer"><!-- --></div>
	<div id="BJ_Bottoms">
		<?php if($user1 || $user2 || $user3 || $user4){?>
		<div class="inner lighter">
		<div class="column">
			<jdoc:include type="modules" name="user1" heading="<?php echo $moduleheading;?>" style="venus" />
		</div>
		<div class="column">
			<jdoc:include type="modules" name="user2" heading="<?php echo  $moduleheading;?>" style="venus" />
		</div>
		<div class="column">
			<jdoc:include type="modules" name="user3" heading="<?php echo  $moduleheading;?>" style="venus" />
		</div>
		<div class="column">
			<jdoc:include type="modules" name="user4" heading="<?php echo  $moduleheading;?>" style="venus" />
		</div>
		<div class="clearer"><!-- --></div>
		</div>
		<?php }?>
		<div class="inner">
			<div class="clearer"><!-- --></div>
			<div id="BJ_Footer">
				<div id="BJ_Foot">					
					<?php  include_once(_TEMPLATE_PATH.'/css/bottom.css.php');?>					
				</div>
				<div id="BJ_Foot_Menu">
					<jdoc:include type="modules" name="footer" style="raw" />
				</div>
				<div class="clearer"><!-- --></div>
			</div>
			<div class="clearer"><!-- --></div>
		</div>
	</div>
	<div class="clearer"><!-- --></div>
</div>
<?php include_once(_TEMPLATE_PATH . DS . 'css' . DS . 'footer.css.php') ?>
</div>
</center>
<script language="javascript" type="text/javascript" src="<?php echo _TEMPLATE_URL?>/func/venus.js">
</script>
</body>
</html>